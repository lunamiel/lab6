test_that("mu component is returned correctly", {
  res = myncurve(mu = 10, sigma = 5, a = 6, plot = FALSE)
  expect_equal(res$mu, 10)
})

test_that("sigma component is returned correctly", {
  res = myncurve(mu = 10, sigma = 5, a = 6, plot = FALSE)
  expect_equal(res$sigma, 5)
})

test_that("a component is returned correctly", {
  res = myncurve(mu = 10, sigma = 5, a = 6, plot = FALSE)
  expect_equal(res$a, 6)
})

test_that("prob component equals P(X <= a)", {
  res = myncurve(mu = 10, sigma = 5, a = 6, plot = FALSE)
  expect_equal(res$prob, round(pnorm(6, mean = 10, sd = 5), 4))
  expect_equal(res$prob + res$upper, 1)
  expect_equal(res$check, res$prob)
})

test_that("confidence interval is valid and contains the estimate", {
  res = myncurve(mu = 10, sigma = 5, a = 6, n = 25, plot = FALSE)
  expect_true(res$ci[["lower"]] < res$prob && res$prob < res$ci[["upper"]])
  expect_true(all(res$ci >= 0 & res$ci <= 1))
})

test_that("returns a myncurve object and rejects bad input", {
  expect_s3_class(myncurve(0, 1, 0, plot = FALSE), "myncurve")
  expect_error(myncurve(mu = 10, sigma = -5, a = 6), "sigma")
  expect_error(myncurve(mu = "ten", sigma = 5, a = 6), "mu")
  expect_error(myncurve(mu = 10, sigma = 5, a = 6, n = 1), "n")
})
