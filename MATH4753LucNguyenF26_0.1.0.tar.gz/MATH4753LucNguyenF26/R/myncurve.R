#' Normal curve with shaded lower tail area
#'
#' Draws the density of \eqn{X \sim N(\mu, \sigma^2)}, shades the region under
#' the curve from \eqn{-\infty} to \code{a}, and returns \eqn{P(X \le a)}
#' in a named list. Compared with the basic lab version it also
#' \itemize{
#'   \item checks every input and gives a clear error message,
#'   \item reports the z score of \code{a} and the upper tail \eqn{P(X > a)},
#'   \item double checks \code{pnorm()} by numerically integrating the density,
#'   \item when \code{n} is supplied (meaning \code{mu} and \code{sigma} are a
#'         sample mean and sample standard deviation from \code{n}
#'         observations), gives a delta method confidence interval for the
#'         estimated probability, built on the probit (z) scale so the
#'         interval always stays inside \[0, 1\],
#'   \item returns an S3 object of class \code{"myncurve"} with its own
#'         \code{print()} method.
#' }
#'
#' @details With \eqn{\hat z = (a - \bar{x}) / s}, the delta method gives
#'   \eqn{Var(\hat z) \approx 1/n + \hat z^2 / (2(n - 1))}. The interval
#'   \eqn{\hat z \pm z_{1 - \alpha/2} SE(\hat z)} is then mapped back through
#'   \code{pnorm()}.
#'
#' @param mu Mean of the normal distribution (a single finite number).
#' @param sigma Standard deviation (a single positive number).
#' @param a Upper limit of the shaded area (a single finite number).
#' @param n Optional sample size. If given, \code{mu} and \code{sigma} are
#'   treated as estimates and a confidence interval for the probability is
#'   returned. Must be at least 2.
#' @param conf.level Confidence level for the interval. Defaults to 0.95.
#' @param plot Logical, draw the plot? Defaults to \code{TRUE}.
#' @param col Fill colour for the shaded area.
#'
#' @return An object of class \code{"myncurve"}: a named list with
#'   \code{mu}, \code{sigma}, \code{a}, \code{prob} (\eqn{P(X \le a)} rounded
#'   to 4 decimal places), \code{upper} (\eqn{P(X > a)}), \code{z},
#'   \code{check} (the numerically integrated area) and, when \code{n} is
#'   given, \code{n}, \code{conf.level} and \code{ci}.
#'
#' @importFrom graphics curve polygon abline text legend
#' @importFrom stats dnorm pnorm qnorm integrate
#' @export
#'
#' @examples
#' myncurve(mu = 10, sigma = 5, a = 6)
#' # treat mu and sigma as estimates from 25 observations
#' myncurve(mu = 10, sigma = 5, a = 6, n = 25)
myncurve = function(mu, sigma, a, n = NULL, conf.level = 0.95,
                    plot = TRUE, col = "#8DB255") {
  # input validation
  is_num1 = function(v) is.numeric(v) && length(v) == 1 && is.finite(v)
  if (!is_num1(mu)) stop("'mu' must be a single finite number")
  if (!is_num1(sigma) || sigma <= 0) stop("'sigma' must be a single positive number")
  if (!is_num1(a)) stop("'a' must be a single finite number")
  if (!is.null(n) && (!is_num1(n) || n < 2)) stop("'n' must be a single number >= 2")
  if (!is_num1(conf.level) || conf.level <= 0 || conf.level >= 1)
    stop("'conf.level' must be between 0 and 1")

  # probabilities
  prob = pnorm(a, mean = mu, sd = sigma)
  z = (a - mu) / sigma
  check = integrate(dnorm, lower = -Inf, upper = a, mean = mu, sd = sigma)$value

  out = list(mu = mu, sigma = sigma, a = a,
             prob = round(prob, 4), upper = round(1 - prob, 4),
             z = round(z, 4), check = round(check, 4))

  # delta method CI on the probit scale (only when parameters are estimates)
  if (!is.null(n)) {
    se_z = sqrt(1 / n + z^2 / (2 * (n - 1)))
    crit = qnorm(1 - (1 - conf.level) / 2)
    out$n = n
    out$conf.level = conf.level
    out$ci = round(pnorm(z + c(-1, 1) * crit * se_z), 4)
    names(out$ci) = c("lower", "upper")
  }

  # plot
  if (plot) {
    dens = function(x) dnorm(x, mean = mu, sd = sigma)
    lo = min(mu - 4 * sigma, a - sigma)
    hi = max(mu + 4 * sigma, a + sigma)
    curve(dens, xlim = c(lo, hi), lwd = 2,
          ylim = c(0, 1.1 * dnorm(mu, mu, sigma)),
          xlab = "x", ylab = "Normal density",
          main = bquote("N(" * mu == .(mu) * "," ~ sigma == .(sigma) * ")," ~
                          P(X <= .(a)) == .(out$prob)))
    xcurve = seq(lo, a, length = 1000)
    ycurve = dnorm(xcurve, mean = mu, sd = sigma)
    polygon(c(lo, xcurve, a), c(0, ycurve, 0), col = col, border = NA)
    curve(dens, add = TRUE, lwd = 2)
    abline(v = mu, lty = 2, col = "grey40")
    abline(v = a, lwd = 2, col = "#3E5C2A")
    lab = paste0("Area = ", out$prob, "\nz = ", out$z)
    if (!is.null(n))
      lab = paste0(lab, "\n", 100 * conf.level, "% CI: [",
                   out$ci[1], ", ", out$ci[2], "]")
    text(x = hi, y = dnorm(mu, mu, sigma), labels = lab, adj = c(1, 1), cex = 0.9)
  }

  class(out) = c("myncurve", "list")
  invisible(out)
}

#' Print method for myncurve objects
#'
#' @param x An object returned by \code{\link{myncurve}}.
#' @param ... Not used.
#' @return \code{x}, invisibly.
#' @export
print.myncurve = function(x, ...) {
  cat("Normal lower tail area\n")
  cat("  X ~ N(mu = ", x$mu, ", sigma = ", x$sigma, ")\n", sep = "")
  cat("  P(X <= ", x$a, ") = ", x$prob, "   (z = ", x$z, ")\n", sep = "")
  cat("  P(X >  ", x$a, ") = ", x$upper, "\n", sep = "")
  cat("  Numerical integration check: ", x$check, "\n", sep = "")
  if (!is.null(x$ci))
    cat("  ", 100 * x$conf.level, "% delta method CI (n = ", x$n, "): [",
        x$ci[1], ", ", x$ci[2], "]\n", sep = "")
  invisible(x)
}
